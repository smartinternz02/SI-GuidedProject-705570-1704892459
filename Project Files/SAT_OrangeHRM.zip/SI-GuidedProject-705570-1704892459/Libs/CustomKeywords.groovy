
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import com.kms.katalon.core.testobject.TestObject

import java.lang.String



def static "com.admin.ListVerifier.verifyRowCount"(
    	TestObject tableBody	
     , 	String outerTagName	
     , 	int count	) {
    (new com.admin.ListVerifier()).verifyRowCount(
        	tableBody
         , 	outerTagName
         , 	count)
}
